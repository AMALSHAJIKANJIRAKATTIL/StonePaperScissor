let images=['paper.png','rock.png','Scissor.png']
let playerchoose=[];
let computerchoose=[];
function startgame(){
    let turns=document.querySelector('#turn').value;
    turns=parseInt(turns)
    
    if(!turns){
        alert('Enter how many number of turns!!!')
    }else{
       
        var div = document.querySelector('.gamescreen');
        div.style.display = "flex";
        
        
        
        
    }
}


function random(){
    let index=Math.floor(Math.random()* images.length);
    let imagesel=images[index];
    computerchoose.push(index);
    document.querySelector('#computerimage').src=`./src/${imagesel}`;
}

function image(){
    let buttons = document.querySelectorAll('.button');
    Array.from(buttons).forEach((button)=>{
      button.addEventListener('click', (e)=>{
        if(e.target.innerHTML === 'Rock'){
            document.querySelector('#playerimage').src=`./src/rock.png`;
            playerchoose.push(1)
        }
        else if(e.target.innerHTML === 'Paper'){
            playerchoose.push(0)
            document.querySelector('#playerimage').src=`./src/paper.png`;
        }
        else if(e.target.innerHTML === 'Scissor'){
            playerchoose.push(2)
            document.querySelector('#playerimage').src=`./src/Scissor.png`;
          }
      })
    })
}

function result(){

console.log(playerchoose,computerchoose)
}